Il y a 2 .sh:

tp.sh exécute la commande: python code.py, celle-ci marche sur mon windows

tp_python3 exécute: python3 code.py, utilise si vous utiliser linux